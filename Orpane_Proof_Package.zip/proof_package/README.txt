===============================================================================
ORPANE LOSSLESS COMPRESSOR - INDEPENDENT VERIFICATION & PROOF PACKAGE
===============================================================================

This proof package demonstrates bit-exact reversibility and compression density
of Orpane (MAX_RATIO profile) compared directly against 7-Zip 26.02 on maximum 
compression settings (-mx=9 -md=64m -mfb=273 -ms=off).

Standard Public Benchmark Files Selected:
1. alice29.txt (Canterbury Corpus - English prose text, 152,089 bytes)
2. pic         (Calgary Corpus - 1-bit high-resolution scanned bitmap, 513,216 bytes)

-------------------------------------------------------------------------------
1. BENCHMARK COMPARISON TABLE
-------------------------------------------------------------------------------
File: alice29.txt (English text)
  Original uncompressed:  152,089 bytes
  7-Zip 26.02 (-mx9):      48,586 bytes
  Orpane (MAX_RATIO):      42,923 bytes
  Net Bytes Saved:          5,663 bytes (-11.66% smaller than 7-Zip)

File: pic (Binary bitmap image)
  Original uncompressed:  513,216 bytes
  7-Zip 26.02 (-mx9):      40,060 bytes
  Orpane (MAX_RATIO):      37,033 bytes
  Net Bytes Saved:          3,027 bytes (-7.56% smaller than 7-Zip)

Total Across Both Files:
  Original:               665,305 bytes
  7-Zip 26.02 (-mx9):      88,646 bytes
  Orpane (MAX_RATIO):      79,956 bytes
  Grand Total Net Saving:   8,690 bytes (-9.80% net space reduction vs 7-Zip)

-------------------------------------------------------------------------------
2. PACKAGE STRUCTURE
-------------------------------------------------------------------------------
Folder 1: 1_original_files/
  - alice29.txt  (152,089 bytes)
  - pic          (513,216 bytes)

Folder 2: 2_compressed_files/
  - alice29.txt.7z      (48,586 bytes, 7-Zip -mx9)
  - alice29.txt.orpane  (42,923 bytes, Orpane MAX_RATIO)
  - pic.7z              (40,060 bytes, 7-Zip -mx9)
  - pic.orpane          (37,033 bytes, Orpane MAX_RATIO)

Folder 3: 3_decompressed_files/
  - alice29_decompressed_by_7z.txt      (152,089 bytes, byte-for-byte identical)
  - alice29_decompressed_by_orpane.txt  (152,089 bytes, byte-for-byte identical)
  - pic_decompressed_by_7z              (513,216 bytes, byte-for-byte identical)
  - pic_decompressed_by_orpane          (513,216 bytes, byte-for-byte identical)

-------------------------------------------------------------------------------
3. CRYPTOGRAPHIC CHECKSUMS (SHA-256)
-------------------------------------------------------------------------------
alice29.txt (Original):
  7467306ee0feed4971260f3c87421154a05be571d944e9cb021a5713700c38f0
alice29_decompressed_by_7z.txt:
  7467306ee0feed4971260f3c87421154a05be571d944e9cb021a5713700c38f0
alice29_decompressed_by_orpane.txt:
  7467306ee0feed4971260f3c87421154a05be571d944e9cb021a5713700c38f0
Status: 100% BIT-EXACT MATCH (0 differences, 0 bytes altered).

pic (Original):
  0ec3a75089bb52342813496b17e51377bc9eba3cb519a444d67025354841d650
pic_decompressed_by_7z:
  0ec3a75089bb52342813496b17e51377bc9eba3cb519a444d67025354841d650
pic_decompressed_by_orpane:
  0ec3a75089bb52342813496b17e51377bc9eba3cb519a444d67025354841d650
Status: 100% BIT-EXACT MATCH (0 differences, 0 bytes altered).

-------------------------------------------------------------------------------
4. HOW TO VERIFY LOCALLY
-------------------------------------------------------------------------------
A. Verify SHA-256 Checksums:
   Linux/macOS:
     sha256sum -c CHECKSUMS_SHA256.txt
   Windows PowerShell:
     Get-FileHash .\1_original_files\* .\3_decompressed_files\* -Algorithm SHA256

B. Bitwise Binary Comparison:
   Linux:
     cmp 1_original_files/alice29.txt 3_decompressed_files/alice29_decompressed_by_orpane.txt
     cmp 1_original_files/pic 3_decompressed_files/pic_decompressed_by_orpane
   Windows:
     fc.exe /B 1_original_files\alice29.txt 3_decompressed_files\alice29_decompressed_by_orpane.txt
     fc.exe /B 1_original_files\pic 3_decompressed_files\pic_decompressed_by_orpane
   (Expected output: "FC: no differences encountered")

===============================================================================
