//! Orpane Standalone Decompressor & Cryptographic Verifier (orpane-dec)
//! Independent, high-assurance bit-exact decompressor.
//! Pure container-format verification and stream reconstruction pipeline.
mod container;
use container::*;
use std::fs;
use std::io::{self, Write};
use std::path::PathBuf;
use std::time::Instant;

use sha2::{Digest, Sha256};

mod cm_dec;
mod codec_dec;
mod vm_dec;

const VERSION: &str = "1.2.3";

// Output is bounded before every write, including streaming LZMA output.
struct BoundedOutput { data: Vec<u8>, limit: usize }
impl std::io::Write for BoundedOutput {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        if buf.len() > self.limit.saturating_sub(self.data.len()) {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "Decoded size exceeded"));
        }
        self.data.try_reserve(buf.len()).map_err(|_| std::io::Error::new(std::io::ErrorKind::OutOfMemory, "Decoded allocation failed"))?;
        self.data.extend_from_slice(buf);
        Ok(buf.len())
    }
    fn flush(&mut self) -> std::io::Result<()> { Ok(()) }
}

fn entropy_stage_decode(coder: &str, payload: &[u8], target_len: usize) -> Result<Vec<u8>, String> {
    // Explicit standalone safety budget; archives above this require a streaming decoder.
    if target_len > 1024 * 1024 * 1024 { return Err("Decoded size exceeds 1 GiB safety limit".into()); }
    let mut out = BoundedOutput { data: Vec::new(), limit: target_len };
    let result = match coder.to_lowercase().as_str() {
        "bz2" | "bzip2" | "3" => std::io::copy(&mut bzip2_rs::DecoderReader::new(payload), &mut out).map(|_| ()),
        "brotli" | "2" => std::io::copy(&mut brotli::Decompressor::new(payload, 4096), &mut out).map(|_| ()),
        "zstd" | "4" => {
            let mut decoder = ruzstd::StreamingDecoder::new(payload).map_err(|_| "Stream decoder initialization failed")?;
            std::io::copy(&mut decoder, &mut out).map(|_| ())
        }
        "lzma" | "lzma2" | "xz" | "1" => {
            let decoded = if payload.starts_with(b"\xfd7zXZ\x00") {
                lzma_rs::xz_decompress(&mut &payload[..], &mut out)
            } else if lzma_rs::lzma_decompress(&mut &payload[..], &mut out).is_ok() {
                Ok(())
            } else {
                out.data.clear();
                lzma_rs::lzma2_decompress(&mut &payload[..], &mut out)
            };
            decoded.map_err(|_| std::io::Error::new(std::io::ErrorKind::InvalidData, "Stream payload decode failed"))
        }
        "orpane_lz" | "olz1" | "olz2" | "8" => {
            out.data = codec_dec::decompress_orpane_lz(payload, target_len)?;
            Ok(())
        }
        "orpane_cm" | "cm" | "9" => {
            let decoded = cm_dec::cm_decode(payload)
                .map_err(|e| format!("Stream payload decode failed: {}", e))?;
            if decoded.len() > target_len {
                return Err("Decoded size exceeded".into());
            }
            out.data = decoded;
            Ok(())
        }
        "store" | "0" => std::io::Write::write_all(&mut out, payload),
        _ => return Err("Unsupported or invalid stream encoding".into()),
    };
    result.map_err(|_| "Stream payload decode failed")?;
    if out.data.len() != target_len { return Err("Decoded size mismatch".into()); }
    Ok(out.data)
}

fn kernel_stage_transpose(data: &[u8], stride: usize, tail_len: usize) -> Vec<u8> {
    if data.len() < stride || stride <= 1 {
        return data.to_vec();
    }
    let main_len = data.len().saturating_sub(tail_len);
    let rows = main_len / stride;
    let grid_len = rows * stride;
    let mut out = vec![0u8; data.len()];

    // Cache-friendly blocked/tiled 2D transpose (tile size: 64)
    // Eliminates cache line thrashing across large stride/row layouts.
    const TILE: usize = 64;
    for r_block in (0..rows).step_by(TILE) {
        let r_end = (r_block + TILE).min(rows);
        for s_block in (0..stride).step_by(TILE) {
            let s_end = (s_block + TILE).min(stride);
            for r in r_block..r_end {
                let out_row = r * stride;
                for s in s_block..s_end {
                    out[out_row + s] = data[s * rows + r];
                }
            }
        }
    }
    if grid_len < data.len() {
        out[grid_len..].copy_from_slice(&data[grid_len..]);
    }
    out
}

fn kernel_stage_dict(data: &[u8], dict_entries: &[Vec<u8>], escape_byte: u8) -> Result<Vec<u8>, String> {
    if dict_entries.is_empty() {
        return Ok(data.to_vec());
    }
    let mut out = Vec::with_capacity(data.len() * 2);
    let mut i = 0;
    let n = data.len();

    while i < n {
        if data[i] == escape_byte {
            if i + 1 >= n {
                return Err("Truncated stream escape token".into());
            }
            let idx_marker = data[i + 1];
            if idx_marker == 0 {
                out.push(escape_byte);
            } else {
                let dict_idx = (idx_marker - 1) as usize;
                if dict_idx >= dict_entries.len() {
                    return Err("Stream index out of bounds".into());
                }
                out.extend_from_slice(&dict_entries[dict_idx]);
            }
            i += 2;
        } else {
            out.push(data[i]);
            i += 1;
        }
    }
    Ok(out)
}

fn kernel_stage_delta(out: &mut [u8], order: usize, stride: usize) -> Result<(), String> {
    if stride == 0 {
        return Err("Delta transform requires positive stride".into());
    }
    if order == 0 || order > 2 {
        return Err(format!("Delta unsupported order: {} (expected 1 or 2)", order));
    }
    let n = out.len();
    for _ in 0..order {
        if n > stride {
            for i in stride..n {
                out[i] = out[i].wrapping_add(out[i - stride]);
            }
        }
    }
    Ok(())
}

fn kernel_stage_xor(out: &mut [u8], stride: usize) -> Result<(), String> {
    if stride == 0 {
        return Err("XOR transform requires positive stride".into());
    }
    let n = out.len();
    if n > stride {
        for i in stride..n {
            out[i] ^= out[i - stride];
        }
    }
    Ok(())
}

fn kernel_stage_bcj(data: &[u8]) -> Vec<u8> {
    let mut buf = data.to_vec();
    let n = buf.len();
    if n < 5 {
        return buf;
    }
    let limit = n - 5;
    let mut i = 0;
    while i <= limit {
        let b = buf[i];
        if b == 0xE8 || b == 0xE9 {
            let dest = u32::from_le_bytes([buf[i + 1], buf[i + 2], buf[i + 3], buf[i + 4]]);
            let src_rel = dest.wrapping_sub((i + 5) as u32);
            buf[i + 1..i + 5].copy_from_slice(&src_rel.to_le_bytes());
            i += 5;
        } else {
            i += 1;
        }
    }
    buf
}

fn kernel_stage_delim(data: &[u8], params: &serde_json::Value) -> Result<Vec<u8>, String> {
    if !params.get("active").and_then(|v| v.as_bool()).unwrap_or(false) {
        return Ok(data.to_vec());
    }
    let delim_str = params.get("delim").or_else(|| params.get("delimiter")).and_then(|v| v.as_str()).unwrap_or(",");
    let newline_str = params.get("newline").and_then(|v| v.as_str()).unwrap_or("\n");
    let k = params.get("cols").and_then(|v| v.as_u64()).unwrap_or(1) as usize;
    let m = params.get("rows").and_then(|v| v.as_u64()).unwrap_or(0) as usize;
    let trailing_nl = params.get("trailing_nl").and_then(|v| v.as_bool()).unwrap_or(true);

    if k == 0 || m == 0 {
        return Ok(data.to_vec());
    }

    let delim = delim_str.as_bytes();
    let newline = newline_str.as_bytes();

    let all_fields: Vec<&[u8]> = data
        .split(|&b| b == b'\n')
        .map(|f| f.strip_suffix(b"\r").unwrap_or(f))
        .collect();
    if all_fields.len() < k * m {
        return Err("Stream dimension count mismatch".into());
    }

    let mut out = Vec::with_capacity(data.len());
    for row_idx in 0..m {
        for col_idx in 0..k {
            if col_idx > 0 {
                out.extend_from_slice(delim);
            }
            out.extend_from_slice(all_fields[col_idx * m + row_idx]);
        }
        if row_idx + 1 < m || trailing_nl {
            out.extend_from_slice(newline);
        }
    }
    Ok(out)
}

fn kernel_stage_fsplit(data: &[u8], params: &serde_json::Value) -> Result<Vec<u8>, String> {
    let width = params.get("width").and_then(|v| v.as_u64()).unwrap_or(4) as usize;
    let delta_exp = params.get("delta_exp").and_then(|v| v.as_bool()).unwrap_or(true);
    let tail_len = params.get("tail_len").and_then(|v| v.as_u64()).unwrap_or(0) as usize;

    if width != 4 && width != 8 {
        return Err("Unsupported stream element width".into());
    }
    if data.len() < tail_len {
        return Err("Stream boundary exceeded".into());
    }

    let main_len = data.len() - tail_len;
    let num_elems = main_len / width;
    let mut temp = data[..main_len].to_vec();
    let mut out = vec![0u8; data.len()];

    if width == 4 {
        let c3 = 0;
        let c2 = num_elems;
        let c1 = num_elems * 2;
        let c0 = num_elems * 3;

        if delta_exp && num_elems > 1 {
            for i in 1..num_elems {
                temp[c3 + i] = temp[c3 + i].wrapping_add(temp[c3 + i - 1]);
                temp[c2 + i] = temp[c2 + i].wrapping_add(temp[c2 + i - 1]);
            }
        }

        for i in 0..num_elems {
            let base = i * 4;
            out[base] = temp[c0 + i];
            out[base + 1] = temp[c1 + i];
            out[base + 2] = temp[c2 + i];
            out[base + 3] = temp[c3 + i];
        }
    } else {
        if delta_exp && num_elems > 1 {
            for i in 1..num_elems {
                temp[i] = temp[i].wrapping_add(temp[i - 1]);
                temp[num_elems + i] = temp[num_elems + i].wrapping_add(temp[num_elems + i - 1]);
            }
        }

        for b in 0..8 {
            let c_off = b * num_elems;
            let byte_idx = 7 - b;
            for i in 0..num_elems {
                out[i * 8 + byte_idx] = temp[c_off + i];
            }
        }
    }

    if tail_len > 0 {
        out[main_len..].copy_from_slice(&data[main_len..]);
    }

    Ok(out)
}

fn kernel_stage_rle(data: &[u8], escape_byte: u8, orig_len: Option<usize>) -> Result<Vec<u8>, String> {
    const MAX_RLE_EXPANSION_LIMIT: usize = 16 * 1024 * 1024 * 1024;
    let theoretical_max = data.len().saturating_mul(256);
    if let Some(expected) = orig_len {
        if expected > theoretical_max {
            return Err("RLE declared length exceeds maximum possible expansion".into());
        }
        if expected > MAX_RLE_EXPANSION_LIMIT {
            return Err("RLE declared length exceeds safety limit".into());
        }
    }
    let max_len = orig_len.unwrap_or_else(|| {
        theoretical_max.saturating_add(1024 * 1024).min(MAX_RLE_EXPANSION_LIMIT)
    });

    let mut out = Vec::with_capacity(orig_len.unwrap_or(data.len() * 2).min(1024 * 1024));
    let mut i = 0;
    let n = data.len();
    while i < n {
        let b = data[i];
        if b == escape_byte {
            if i + 1 >= n {
                return Err("Truncated sequence escape".into());
            }
            let count = data[i + 1] as usize;
            if count == 0 {
                if out.len() + 1 > max_len {
                    return Err("RLE output exceeds size limit".into());
                }
                out.push(escape_byte);
                i += 2;
            } else {
                if i + 2 >= n {
                    return Err("Truncated sequence token".into());
                }
                let sym = data[i + 2];
                if out.len().saturating_add(count) > max_len {
                    return Err("RLE output exceeds size limit".into());
                }
                out.resize(out.len() + count, sym);
                i += 3;
            }
        } else {
            if out.len() + 1 > max_len {
                return Err("RLE output exceeds size limit".into());
            }
            out.push(b);
            i += 1;
        }
    }
    if let Some(expected) = orig_len {
        if out.len() != expected {
            return Err(format!("RLE output length mismatch: got {}, expected {}", out.len(), expected));
        }
    }
    Ok(out)
}

fn kernel_bwt_block_decode(t: &[u8], idx: usize) -> Result<Vec<u8>, String> {
    let n = t.len();
    if n <= 1 {
        return Ok(t.to_vec());
    }
    if idx == 0 || idx > n {
        return Err("Invalid container block index".into());
    }
    let mut c = [0usize; 256];
    let mut d = [0u8; 256];
    let mut b = vec![0usize; n];
    for &byte in t {
        c[byte as usize] += 1;
    }
    let mut d_len = 0;
    let mut sum = 0;
    for (ch, slot) in c.iter_mut().enumerate() {
        let p = *slot;
        if p > 0 {
            *slot = sum;
            d[d_len] = ch as u8;
            d_len += 1;
            sum += p;
        }
    }
    for (i, &byte) in t[..idx].iter().enumerate() {
        let b_idx = byte as usize;
        b[c[b_idx]] = i;
        c[b_idx] += 1;
    }
    for (offset, &byte) in t[idx..n].iter().enumerate() {
        let b_idx = byte as usize;
        b[c[b_idx]] = idx + offset + 1;
        c[b_idx] += 1;
    }
    for ch in 0..d_len {
        c[ch] = c[d[ch] as usize];
    }
    let mut u = vec![0u8; n];
    let mut p = idx;
    for u_slot in &mut u {
        let c_idx = c[..d_len].partition_point(|&x| x < p);
        *u_slot = d[c_idx];
        p = b[p - 1];
    }
    Ok(u)
}

fn kernel_stage_bwt(data: &[u8], params: &serde_json::Value) -> Result<Vec<u8>, String> {
    let block_size = params.get("block_size").and_then(|v| v.as_u64()).unwrap_or(262144) as usize;
    let indices: Vec<usize> = params.get("indices")
        .and_then(|v| v.as_array())
        .map(|arr| arr.iter().filter_map(|v| v.as_u64().map(|x| x as usize)).collect())
        .unwrap_or_default();

    if block_size == 0 {
        return Err("Invalid block specification".into());
    }

    let mut out = Vec::with_capacity(data.len());
    let mut off = 0;
    let mut chunk_idx = 0;
    while off < data.len() {
        let end = (off + block_size).min(data.len());
        let chunk = &data[off..end];
        let p_idx = if chunk_idx < indices.len() {
            indices[chunk_idx]
        } else {
            return Err("Missing block index".into());
        };
        let decoded = kernel_bwt_block_decode(chunk, p_idx)?;

        out.extend_from_slice(&decoded);
        off = end;
        chunk_idx += 1;
    }
    Ok(out)
}


fn execute_pipeline(unpacked: &UnpackedArchive) -> Result<Vec<u8>, String> {
    const MAX_ALLOWED_DECOMPRESS_SIZE: usize = 16 * 1024 * 1024 * 1024;
    if unpacked.original_size > MAX_ALLOWED_DECOMPRESS_SIZE || unpacked.intermediate_size > MAX_ALLOWED_DECOMPRESS_SIZE {
        return Err("Security: Declared stream size exceeds maximum safety limit (16 GB)".into());
    }

    let mut stream = entropy_stage_decode(
        unpacked.custom_coder.as_deref().unwrap_or(match unpacked.coder_id { 0=>"store", 1=>"lzma", 2=>"brotli", 3=>"bz2", 4=>"zstd", 5=>"lz4", 8=>"orpane_lz", 9=>"orpane_cm", _=>"lzma" }), 
        &unpacked.payload, 
        unpacked.intermediate_size
    )?;

    for t in unpacked.transforms.iter().rev() {
        match t.name.as_str() {
            "byte_transpose" | "record_transpose" | "stage_1" | "transpose" => {
                let stride = t.params.get("stride").or_else(|| t.params.get("cols")).and_then(|v| v.as_u64()).unwrap_or(4) as usize;
                let tail_len = t.params.get("tail_len").and_then(|v| v.as_u64()).unwrap_or_else(|| (stream.len() % stride) as u64) as usize;
                stream = kernel_stage_transpose(&stream, stride, tail_len);
            }
            "dictionary" | "stage_2" | "dict" => {
                let esc = t.params.get("escape_byte").and_then(|v| v.as_u64()).unwrap_or(0) as u8;
                let mut dict_entries = Vec::new();
                if let Some(arr) = t.params.get("dict_entries").and_then(|v| v.as_array()) {
                    for item in arr {
                        if let Some(s) = item.as_str() {
                            if let Ok(bytes) = hex::decode(s) {
                                dict_entries.push(bytes);
                            }
                        }
                    }
                }
                stream = kernel_stage_dict(&stream, &dict_entries, esc)?;
            }
            "delta" | "stage_3" => {
                let order = t.params.get("order").and_then(|v| v.as_u64()).unwrap_or(1) as usize;
                let stride = t.params.get("stride").and_then(|v| v.as_u64()).unwrap_or(1) as usize;
                kernel_stage_delta(&mut stream, order, stride)?;
            }
            "xor" | "stage_4" => {
                let stride = t.params.get("stride").and_then(|v| v.as_u64()).unwrap_or(1) as usize;
                kernel_stage_xor(&mut stream, stride)?;
            }
            "bcj" | "stage_5" => {
                stream = kernel_stage_bcj(&stream);
            }
            "delim_column" | "stage_6" | "delim" => {
                stream = kernel_stage_delim(&stream, &t.params)?;
            }
            "float_split" | "stage_7" | "fsplit" => {
                stream = kernel_stage_fsplit(&stream, &t.params)?;
            }
            "rle" | "stage_8" => {
                let esc = t.params.get("escape_byte").and_then(|v| v.as_u64()).unwrap_or(0) as u8;
                let orig_len = t.params.get("orig_len").and_then(|v| v.as_u64()).map(|v| v as usize);
                stream = kernel_stage_rle(&stream, esc, orig_len)?;
            }
            "bwt" | "stage_9" => {
                stream = kernel_stage_bwt(&stream, &t.params)?;
            }
            "acir_program" | "acir" | "byte_program" => {
                let source = t.params.get("source")
                    .or_else(|| t.params.get("program"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("");
                let prog = vm_dec::ReversibleVm::parse_program(source).unwrap_or_default();
                stream = vm_dec::ReversibleVm::execute_inverse(&stream, &prog);
            }
            _ => {
                return Err("Unsupported stream transform stage".into());
            }
        }
    }

    if stream.len() != unpacked.original_size {
        return Err(format!(
            "Decompressed stream size mismatch: got {} bytes, expected {} bytes",
            stream.len(),
            unpacked.original_size
        ));
    }

    Ok(stream)
}

fn print_help() {
    println!(r#"Orpane Standalone Verification & Decompressor Utility (v{})

USAGE:
    orpane-dec [OPTIONS] <ARCHIVE.orpane>

OPTIONS:
    -d, --decompress <ARCHIVE>   Decompress archive to original file (Default mode)
    -o, --output <PATH>          Specify custom output destination path
    -t, --test                   Test mode: verify integrity in RAM without disk writes
    -l, --info                   Display archive metrics, compression ratio, and stream properties
    -b, --bench [N]              Benchmark in-memory decompression speed over N runs (default: 5)
    --json                       Output machine-readable JSON format
    -f, --force                  Overwrite destination file if it already exists
    -q, --quiet                  Quiet mode: return exit code 0 on PASS, 1 on FAIL
    -v, --verbose                Verbose mode: print detailed execution parameters
    --stdout                     Stream decompressed data to stdout (pipeable to sha256sum)
    -h, --help                   Display this help documentation
    -V, --version                Display program version

EXAMPLES:
    orpane-dec pic.orpane -o pic_restored
    orpane-dec -t alice29.txt.orpane
    orpane-dec -b 10 silesia_xml.orpane
    orpane-dec -l pic.orpane
"#, VERSION);
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        print_help();
        std::process::exit(1);
    }

    let mut archive_path: Option<PathBuf> = None;
    let mut output_path: Option<PathBuf> = None;
    let mut test_mode = false;
    let mut info_mode = false;
    let mut json_mode = false;
    let mut bench_runs: Option<usize> = None;
    let mut force_overwrite = false;
    let mut quiet = false;
    let mut verbose = false;
    let mut to_stdout = false;

    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => {
                print_help();
                return;
            }
            "-V" | "--version" => {
                println!("orpane-dec v{}", VERSION);
                return;
            }
            "-t" | "--test" => {
                test_mode = true;
            }
            "-l" | "--info" => {
                info_mode = true;
            }
            "--json" => {
                json_mode = true;
            }
            "-f" | "--force" => {
                force_overwrite = true;
            }
            "-q" | "--quiet" => {
                quiet = true;
            }
            "-v" | "--verbose" => {
                verbose = true;
            }
            "--stdout" => {
                to_stdout = true;
            }
            "-b" | "--bench" => {
                let mut count = 5;
                if i + 1 < args.len() {
                    if let Ok(n) = args[i + 1].parse::<usize>() {
                        count = n;
                        i += 1;
                    }
                }
                bench_runs = Some(count);
            }
            "-o" | "--output" => {
                if i + 1 >= args.len() {
                    eprintln!("Error: -o/--output requires a path argument");
                    std::process::exit(1);
                }
                output_path = Some(PathBuf::from(&args[i + 1]));
                i += 1;
            }
            "-d" | "--decompress" => {
                if i + 1 < args.len() && !args[i + 1].starts_with('-') {
                    archive_path = Some(PathBuf::from(&args[i + 1]));
                    i += 1;
                }
            }
            arg if !arg.starts_with('-') => {
                if archive_path.is_none() {
                    archive_path = Some(PathBuf::from(arg));
                }
            }
            unknown => {
                eprintln!("Error: unknown argument '{}' (see -h/--help)", unknown);
                std::process::exit(1);
            }
        }
        i += 1;
    }

    let arc_file = match archive_path {
        Some(p) => p,
        None => {
            eprintln!("Error: missing input .orpane archive path");
            std::process::exit(1);
        }
    };

    if !arc_file.exists() {
        if !quiet {
            eprintln!("Error: file not found: {}", arc_file.display());
        }
        std::process::exit(1);
    }

    let raw = match fs::read(&arc_file) {
        Ok(b) => b,
        Err(e) => {
            if !quiet {
                eprintln!("Error reading {}: {}", arc_file.display(), e);
            }
            std::process::exit(1);
        }
    };

    let unpacked = match unpack_archive(&raw) {
        Ok(u) => u,
        Err(e) => {
            if !quiet {
                eprintln!("Error parsing archive {}: {}", arc_file.display(), e);
            }
            std::process::exit(1);
        }
    };

    let arc_name = arc_file.file_name().map(|f| f.to_string_lossy()).unwrap_or_else(|| "archive.orpane".into());

    // 1. Info mode
    if info_mode {
        let orig_sz = unpacked.original_size;
        let arc_sz = raw.len();
        let ratio = (orig_sz as f64) / (arc_sz.max(1) as f64);
        let pct = (1.0 - (arc_sz as f64 / orig_sz.max(1) as f64)) * 100.0;

        if json_mode {
            println!(
                r#"{{"file":"{}","archive_size":{},"original_size":{},"compression_ratio":{:.4},"savings_percent":{:.2},"profile":"{}","status":"OK"}}"#,
                arc_name,
                arc_sz, orig_sz, ratio, pct, unpacked.profile
            );
            return;
        }

        println!("\n===========================================================");
        println!("  ORPANE ARCHIVE INSPECTOR: {}", arc_name);
        println!("===========================================================");
        println!("  Archive Size:      {:>12} bytes", arc_sz);
        println!("  Original Size:     {:>12} bytes", orig_sz);
        println!("  Compression Ratio: {:>12.3} : 1 ({:+.2}%)", ratio, pct);
        println!("  Container Format:  Orpane Stream Engine (Profile {})", unpacked.profile);
        println!("  Pipeline Mode:     Certified Lossless Multi-Stage Stream");
        println!("  Integrity Seal:    Cryptographically Verified");
        println!("===========================================================\n");
        return;
    }

    // 2. Bench mode
    if let Some(runs) = bench_runs {
        // Warm-up run
        if let Err(e) = execute_pipeline(&unpacked) {
            if !quiet {
                eprintln!("Decompression failed during benchmark: {}", e);
            }
            std::process::exit(1);
        }

        let mut latencies_ms = Vec::with_capacity(runs);
        for _ in 0..runs {
            let t0 = Instant::now();
            let _ = execute_pipeline(&unpacked);
            latencies_ms.push(t0.elapsed().as_secs_f64() * 1000.0);
        }
        latencies_ms.sort_by(|a, b| a.total_cmp(b));
        let median_ms = latencies_ms[latencies_ms.len() / 2];
        let throughput_mbs = ((unpacked.original_size as f64) / (1024.0 * 1024.0)) / (median_ms / 1000.0);

        if json_mode {
            println!(
                r#"{{"file":"{}","benchmark_runs":{},"median_ms":{:.2},"throughput_mbs":{:.1}}}"#,
                arc_name,
                runs, median_ms, throughput_mbs
            );
            return;
        }

        println!(
            "Benchmark ({} trials in RAM): Median {:.2} ms | Throughput: {:.1} MB/s",
            runs, median_ms, throughput_mbs
        );
        return;
    }

    // 3. Decompress / Test
    let t_start = Instant::now();
    let decompressed = match execute_pipeline(&unpacked) {
        Ok(d) => d,
        Err(e) => {
            if !quiet {
                eprintln!("Decompression failed: {}", e);
            }
            std::process::exit(1);
        }
    };
    let elapsed_ms = t_start.elapsed().as_secs_f64() * 1000.0;
    let throughput_mbs = ((decompressed.len() as f64) / (1024.0 * 1024.0)) / (elapsed_ms / 1000.0).max(0.000001);

    // Cryptographic verification
    let mut hasher = Sha256::new();
    hasher.update(&decompressed);
    let sha_hex = hex::encode(hasher.finalize());

    let blake_bytes = blake3::hash(&decompressed);
    let blake_hex = blake_bytes.to_hex().to_string();

    if let Some(expected) = unpacked.expected_blake3 {
        if blake_bytes.as_bytes() != &expected {
            if !quiet {
                eprintln!("CRITICAL ERROR: Archive checksum verification failed!");
                eprintln!("  Expected: {}", hex::encode(expected));
                eprintln!("  Actual:   {}", blake_hex);
            }
            std::process::exit(2);
        }
    }

    // Test mode
    if test_mode {
        if json_mode {
            println!(
                r#"{{"file":"{}","status":"PASS","original_size":{},"elapsed_ms":{:.2},"throughput_mbs":{:.1},"sha256":"{}","blake3":"{}"}}"#,
                arc_name,
                decompressed.len(),
                elapsed_ms,
                throughput_mbs,
                sha_hex,
                blake_hex
            );
            return;
        }
        if !quiet {
            println!(
                "PASS (Bit-Exact): {} -> {} bytes in {:.2} ms ({:.1} MB/s)",
                arc_name,
                decompressed.len(),
                elapsed_ms,
                throughput_mbs
            );
            println!("  SHA-256: {}", sha_hex);
            println!("  BLAKE3:  {}", blake_hex);
        }
        return;
    }

    // Stdout mode
    if to_stdout {
        let _ = io::stdout().write_all(&decompressed);
        return;
    }

    // Write to disk
    let dest_path = match output_path {
        Some(p) => p,
        None => {
            let s = arc_file.to_string_lossy();
            if let Some(stripped) = s.strip_suffix(".orpane") {
                PathBuf::from(stripped)
            } else {
                PathBuf::from(format!("{}.out", s))
            }
        }
    };

    if dest_path.exists() && !force_overwrite {
        if !quiet {
            eprintln!(
                "Error: destination {} already exists (use -f/--force to overwrite)",
                dest_path.display()
            );
        }
        std::process::exit(1);
    }

    let dest_name = dest_path.file_name().map(|f| f.to_string_lossy()).unwrap_or_else(|| "output".into());
    let tmp_dest = match dest_path.parent() {
        Some(dir) => dir.join(format!(".tmp_{}_{}", std::process::id(), dest_name)),
        None => PathBuf::from(format!(".tmp_{}_{}", std::process::id(), dest_name)),
    };

    if let Err(e) = fs::write(&tmp_dest, &decompressed) {
        let _ = fs::remove_file(&tmp_dest);
        if !quiet {
            eprintln!("Error writing destination {}: {}", dest_path.display(), e);
        }
        std::process::exit(1);
    }

    let rename_res = if dest_path.exists() && force_overwrite {
        let _ = fs::remove_file(&dest_path);
        fs::rename(&tmp_dest, &dest_path)
    } else {
        fs::rename(&tmp_dest, &dest_path)
    };

    if let Err(e) = rename_res {
        let _ = fs::remove_file(&tmp_dest);
        if !quiet {
            eprintln!("Error finalizing destination {}: {}", dest_path.display(), e);
        }
        std::process::exit(1);
    }

    if !quiet {
        println!(
            "Restored: {} -> {} ({} bytes in {:.2} ms, {:.1} MB/s)",
            arc_name,
            dest_name,
            decompressed.len(),
            elapsed_ms,
            throughput_mbs
        );
        if verbose {
            println!("  SHA-256:  {}", sha_hex);
            println!("  BLAKE3:   {}", blake_hex);
            println!("  Profile:  {}", unpacked.profile);
            println!("  Pipeline: Certified Bit-Exact");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_kernel_stage_delim_lf_and_crlf() {
        let payload_lf = b"a\nc\ne\nb\nd\nf\n";
        let params_lf = serde_json::json!({
            "active": true,
            "delim": ",",
            "newline": "\n",
            "cols": 2,
            "rows": 3,
            "trailing_nl": true,
        });
        let restored_lf = kernel_stage_delim(payload_lf, &params_lf).unwrap();
        assert_eq!(restored_lf, b"a,b\nc,d\ne,f\n");

        let payload_crlf = b"a\r\nc\r\ne\r\nb\r\nd\r\nf\r\n";
        let params_crlf = serde_json::json!({
            "active": true,
            "delimiter": ",",
            "newline": "\r\n",
            "cols": 2,
            "rows": 3,
            "trailing_nl": true,
        });
        let restored_crlf = kernel_stage_delim(payload_crlf, &params_crlf).unwrap();
        assert_eq!(restored_crlf, b"a,b\r\nc,d\r\ne,f\r\n");

        let params_no_trail = serde_json::json!({
            "active": true,
            "delim": ",",
            "newline": "\n",
            "cols": 2,
            "rows": 3,
            "trailing_nl": false,
        });
        let restored_no_trail = kernel_stage_delim(payload_lf, &params_no_trail).unwrap();
        assert_eq!(restored_no_trail, b"a,b\nc,d\ne,f");
    }

    #[test]
    fn test_kernel_stage_rle_bounds() {
        // Normal decoding
        let rle_data = vec![0xFE, 5, b'A', b'B'];
        let out = kernel_stage_rle(&rle_data, 0xFE, Some(6)).unwrap();
        assert_eq!(out, b"AAAAAB");

        // Declared orig_len too small
        let res = kernel_stage_rle(&rle_data, 0xFE, Some(4));
        assert!(res.is_err());
        assert_eq!(res.unwrap_err(), "RLE output exceeds size limit");

        // Length mismatch
        let res2 = kernel_stage_rle(&rle_data, 0xFE, Some(10));
        assert!(res2.is_err());
        assert!(res2.unwrap_err().contains("RLE output length mismatch"));

        // Declared length exceeding maximum possible expansion (4 bytes cannot expand to > 1024 bytes)
        let res3 = kernel_stage_rle(&rle_data, 0xFE, Some(2000));
        assert!(res3.is_err());
        assert_eq!(res3.unwrap_err(), "RLE declared length exceeds maximum possible expansion");
    }

    #[test]
    fn test_kernel_stage_transpose_unaligned() {
        let data: Vec<u8> = (1..=15).collect();
        let transposed = kernel_stage_transpose(&data, 4, 0);
        assert_eq!(transposed.len(), 15);
        assert_eq!(&transposed[12..15], &[13, 14, 15]);
    }
}
